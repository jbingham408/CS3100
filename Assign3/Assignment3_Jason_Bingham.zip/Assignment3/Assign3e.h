/*
        Jason Bingham
        Assignment 3 CS3100
*/

#ifndef ASSIGN3E_H_
#define ASSIGN3E_H_

// estimates e
double calcE(int);
// calculates the factorial of a number
int factorial(int);


#endif /* ASSIGN3E_H_ */
