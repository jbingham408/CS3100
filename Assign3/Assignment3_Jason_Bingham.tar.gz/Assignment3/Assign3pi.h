/*
        Jason Bingham
        Assignment 3 CS3100
*/

#ifndef ASSIGN3PI_H_
#define ASSIGN3PI_H_

#include <cmath>

// calculates pi
double calcPi();



#endif /* ASSIGN3PI_H_ */
