/*
        Jason Bingham
        Assignment 3 CS3100
*/

#ifndef ASSIGN3FIB_H_
#define ASSIGN3FIB_H_

// calculates the fibonacci number
int fibonacci(int);



#endif /* ASSIGN3FIB_H_ */
