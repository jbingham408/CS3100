/*
        Jason Bingham
        Assignment 3 CS3100
*/

#include "Assign3pi.h"

// calculates pi
double calcPi(){
	double pi = 0.0;

	pi += 4.0 * atan(1.0);

	return pi;
}
